package com.example.el_indeciso

enum class Sound {
    CARD_DROP,
    BUTTON_CLICK,
    HAPPY_POP_UP,
    SAD_POP_UP,
    NORMAL_POP_UP,
    GAME_LOST_POP_UP,
    GAME_WON_POP_UP
}