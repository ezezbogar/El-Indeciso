package com.example.el_indeciso

data class Move(val playerId : String? = null, val card : Int = 0) {
}