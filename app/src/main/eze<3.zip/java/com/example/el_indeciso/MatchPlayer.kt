package com.example.el_indeciso

data class MatchPlayer (var nombre: String = "Hola Jorge", var profilePic:String="ABC", var id :String = "0", var ready: Boolean = false) {

}